Raspberry Pi 5 CYW43455 Windows 11 ARM64 - direct SDIO / NDIS build

Configuration: Debug
Platform:      ARM64
Commit:        3569bdb9bd82c0b03e1afdfc64a4e67202365268
Workflow run:  https://github.com/farjanatech/rpi5-wifi-driver-win11arm/actions/runs/32653892619

Architecture:
  ACPI\\RPI5WIFI -> NDIS 6.30 Ethernet miniport -> direct Pi 5 SDHCI -> CYW43455

This package deliberately does NOT depend on Microsoft sdbus and does not bind
to SD\\VID_02D0 child IDs. It maps the SDIO2 MMIO resource itself and performs
CMD0/CMD5/CMD3/CMD7/CMD52 directly.

The driver remains disconnected until the CYW43455 firmware/SDPCM/BCDC and
association datapath are completed. A successful CMD52 diagnostic is a hardware
protocol milestone, NOT a claim that Wi-Fi is working.

Use only with the matching UEFI build that exposes ACPI\\RPI5WIFI and leaves
MAX_50MHZ_MODE untouched. Confirm the physical fan operates normally after boot.
