Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$me = [Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
if (-not $me.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw 'Run as Administrator.' }
$dir = Split-Path -Parent $MyInvocation.MyCommand.Path
$cer = Join-Path $dir 'rpi5cyw-test.cer'
$inf = Join-Path $dir 'rpi5cyw.inf'
certutil.exe -addstore -f Root $cer
certutil.exe -addstore -f TrustedPublisher $cer
pnputil.exe /add-driver $inf /install
pnputil.exe /scan-devices
Write-Host 'Direct-SDIO driver installation attempted.'
Write-Host 'Run collect-direct-sdio-diagnostics.ps1 next.'
