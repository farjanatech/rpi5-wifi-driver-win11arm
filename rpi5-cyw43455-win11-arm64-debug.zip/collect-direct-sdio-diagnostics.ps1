Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'
$dir = Split-Path -Parent $MyInvocation.MyCommand.Path
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$out = Join-Path $dir "direct-sdio-diagnostics-$stamp"
New-Item -ItemType Directory -Path $out -Force | Out-Null

function Capture([string]$Name, [scriptblock]$Command) {
    try { & $Command 2>&1 | Out-String -Width 500 | Set-Content (Join-Path $out $Name) -Encoding UTF8 }
    catch { ($_ | Out-String) | Set-Content (Join-Path $out $Name) -Encoding UTF8 }
}

Capture 'DIRECT-SDIO-RESULT.txt' {
    'Raspberry Pi 5 CYW43455 DIRECT SDIO / NDIS diagnostic'
    ''
    $key = 'HKLM:\SOFTWARE\Rpi5CywDirectDiag'
    if (Test-Path $key) {
        $d = Get-ItemProperty $key
        "Stage=$($d.Stage)"
        ('LastStatus=0x{0:X8}' -f ([uint32]$d.LastStatus))
        ('MMIO=0x{0:X8}{1:X8} Length=0x{2:X}' -f ([uint32]$d.RegPhysHi),([uint32]$d.RegPhysLo),([uint32]$d.RegLength))
        ('HostVersion=0x{0:X4} Capabilities=0x{1:X8} Capabilities2=0x{2:X8}' -f ([uint32]$d.HostVersion),([uint32]$d.Capabilities),([uint32]$d.Capabilities2))
        ('CMD5 probe=0x{0:X8} SDIO OCR=0x{1:X8} functions={2}' -f ([uint32]$d.Cmd5ProbeResponse),([uint32]$d.SdioOcr),$d.SdioFunctions)
        ('RCA=0x{0:X4}' -f ([uint32]$d.RelativeAddress))
        ('CCCR rev=0x{0:X2} IOEx=0x{1:X2} IORx=0x{2:X2} F1 IF=0x{3:X2} F2 IF=0x{4:X2}' -f ([uint32]$d.CccrRevision),([uint32]$d.IoEnable),([uint32]$d.IoReady),([uint32]$d.F1InterfaceCode),([uint32]$d.F2InterfaceCode))
        ''
        if ([int]$d.Stage -ge 90 -and [uint32]$d.LastStatus -eq 0) {
            'DIRECT SDIO RESULT: CMD52 PATH REACHED SUCCESSFULLY'
            'This proves host-to-CYW SDIO command communication only; it is not yet working Wi-Fi.'
        } else {
            'DIRECT SDIO RESULT: PROBE DID NOT REACH COMPLETE CMD52 READS'
            'Use LastCommand/LastArgument/LastInterruptStatus/LastResponse from registry.txt to locate the hardware/protocol failure.'
        }
    } else {
        'DIRECT SDIO RESULT: DRIVER DIAGNOSTIC REGISTRY KEY NOT FOUND'
    }
}
Capture 'registry.txt' { reg.exe query 'HKLM\SOFTWARE\Rpi5CywDirectDiag' /s }
Capture 'windows.txt' { Get-ComputerInfo | Format-List WindowsProductName,WindowsVersion,OsBuildNumber,OsArchitecture,BiosFirmwareType,BiosVersion }
Capture 'bcdedit.txt' { bcdedit /enum '{current}' }
Capture 'pnp-rpi5wifi.txt' {
    Get-PnpDevice -PresentOnly:$false -ErrorAction SilentlyContinue |
      Where-Object { $_.InstanceId -match 'RPI5WIFI' -or $_.FriendlyName -match 'CYW43455|Direct SDIO' } |
      Format-List *
}
Capture 'pnp-properties.txt' {
    $dev = Get-PnpDevice -PresentOnly:$false -ErrorAction SilentlyContinue | Where-Object { $_.InstanceId -match 'RPI5WIFI' } | Select-Object -First 1
    if ($dev) {
        $dev | Format-List *
        Get-PnpDeviceProperty -InstanceId $dev.InstanceId -ErrorAction SilentlyContinue | Format-Table KeyName,Type,Data -AutoSize
    } else { 'ACPI RPI5WIFI device not found' }
}
Capture 'service.txt' { sc.exe query rpi5cyw; sc.exe qc rpi5cyw; reg.exe query 'HKLM\SYSTEM\CurrentControlSet\Services\rpi5cyw' /s }
Capture 'pnputil.txt' { pnputil /enum-devices /connected; pnputil /enum-devices /problem; pnputil /enum-drivers }
Capture 'netadapters.txt' { Get-NetAdapter -IncludeHidden | Format-List Name,InterfaceDescription,Status,LinkSpeed,MacAddress,DriverInformation,DriverFileName,PnPDeviceID }
Capture 'system-events.txt' {
    $start=(Get-Date).AddHours(-6)
    Get-WinEvent -FilterHashtable @{LogName='System';StartTime=$start} -ErrorAction SilentlyContinue |
      Where-Object { $_.ProviderName -match 'Kernel-PnP|NDIS|Service Control Manager' -or $_.Message -match 'RPI5WIFI|rpi5cyw|CYW43455' } |
      Select-Object TimeCreated,Id,LevelDisplayName,ProviderName,Message | Format-List
}
$setup = Join-Path $env:windir 'INF\setupapi.dev.log'
if (Test-Path $setup) { Copy-Item $setup (Join-Path $out 'setupapi.dev.log') -Force }
$zip = Join-Path $dir "RPI5-CYW43455-DIRECT-SDIO-DIAGNOSTICS-$stamp.zip"
Compress-Archive -Path (Join-Path $out '*') -DestinationPath $zip -Force
Write-Host "Diagnostics: $zip"
